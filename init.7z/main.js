var fs = require('fs')

fs.readFile('./users.json' , 'utf-8' , 
    function (err, data) {
        // jika error
        if(err) throw err
        // jika berhasil
        var arrayOfObjects = JSON.parse( data )

        console.log(arrayOfObjects); //OUTPUT = { users: [] }        
        
    }
)